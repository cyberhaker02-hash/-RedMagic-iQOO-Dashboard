package com.iqoo.redmagicdashboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var batteryValue: TextView
    private lateinit var tempValue: TextView
    private lateinit var thermalValue: TextView
    private lateinit var networkValue: TextView

    private val bg = Color.rgb(8, 9, 13)
    private val panel = Color.rgb(21, 22, 29)
    private val red = Color.rgb(255, 48, 59)
    private val white = Color.rgb(245, 245, 248)
    private val muted = Color.rgb(165, 168, 180)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildDashboard()
        refreshStats()
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(24))
        }
        scroll.addView(page)

        page.addView(label("iQOO  •  REDMAGIC EDITION", 13, red, true))
        page.addView(label("GAME SPACE", 30, white, true).apply {
            setPadding(0, dp(4), 0, dp(2))
        })
        page.addView(label("Dashboard gaming • Android", 13, muted, false))
        page.addView(space(18))

        val gameCard = card()
        gameCard.addView(label("FREE FIRE MAX", 19, white, true))
        gameCard.addView(label("Mode dashboard untuk sesi gaming", 12, muted, false))
        gameCard.addView(space(12))
        gameCard.addView(actionButton("BUKA FREE FIRE MAX", red) { launchFreeFire() })
        page.addView(gameCard)

        page.addView(sectionTitle("MONITOR PERANGKAT"))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        batteryValue = statCard(row1, "BATERAI", "--")
        tempValue = statCard(row1, "SUHU BATERAI", "--")
        stats.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        thermalValue = statCard(row2, "STATUS TERMAL", "--")
        networkValue = statCard(row2, "JARINGAN", "--")
        stats.addView(row2)
        page.addView(stats)

        page.addView(sectionTitle("PERFORMA GAME"))
        val perf = card()
        perf.addView(label("FPS aktual: gunakan penghitung bawaan iQOO jika tersedia", 14, white, true))
        perf.addView(space(6))
        perf.addView(label("Aplikasi biasa tidak dapat membaca FPS game lain secara universal. Tidak ada angka FPS simulasi di sini.", 12, muted, false))
        page.addView(perf)

        page.addView(sectionTitle("AKSES CEPAT"))
        val quick = card()
        quick.addView(actionButton("PENGATURAN ANDROID", panel) {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        })
        quick.addView(space(8))
        quick.addView(actionButton("REFRESH MONITOR", panel) { refreshStats(); toast("Data diperbarui") })
        page.addView(quick)

        page.addView(space(14))
        page.addView(label("Dashboard ini tidak mengubah governor CPU/GPU, mengaktifkan mode performa, atau membuka fitur internal REDMAGIC. Gunakan Ultra Game Mode bawaan iQOO untuk pengaturan sistem.", 11, muted, false))
        setContentView(scroll)
    }

    private fun refreshStats() {
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (battery != null) {
            val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryValue.text = if (level >= 0) "${level * 100 / scale}%" else "Tidak diketahui"
            val tenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
            tempValue.text = if (tenths >= 0) String.format(Locale.US, "%.1f°C", tenths / 10.0) else "Tidak tersedia"
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        thermalValue.text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Ringan"
                PowerManager.THERMAL_STATUS_MODERATE -> "Sedang"
                PowerManager.THERMAL_STATUS_SEVERE -> "Tinggi"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Kritis"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Darurat"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
                else -> "Tidak diketahui"
            }
        } else "Tidak didukung"

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        networkValue.text = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Seluler"
            else -> "Terhubung"
        }
    }

    private fun launchFreeFire() {
        val intent = packageManager.getLaunchIntentForPackage("com.dts.freefiremax")
        if (intent != null) startActivity(intent)
        else toast("Free Fire MAX belum terdeteksi. Pastikan game sudah terpasang.")
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        setBackgroundColor(panel)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }

    private fun statCard(parent: LinearLayout, title: String, initial: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(8), dp(12))
            setBackgroundColor(panel)
        }
        parent.addView(box, LinearLayout.LayoutParams(0, dp(92), 1f).apply {
            rightMargin = dp(6); bottomMargin = dp(8)
        })
        box.addView(label(title, 10, muted, true))
        val value = label(initial, 20, white, true)
        box.addView(value)
        return value
    }

    private fun sectionTitle(text: String) = label(text, 12, red, true).apply {
        setPadding(2, dp(12), 2, dp(8))
    }

    private fun actionButton(text: String, color: Int, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            setTextColor(white)
            textSize = 12f
            isAllCaps = false
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            setOnClickListener { action() }
            minHeight = dp(48)
        }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun space(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
