REDMAGIC iQOO Dashboard - Auto Build

PENTING:
- Ini proyek sumber Android dengan GitHub Actions, bukan APK yang sudah jadi.
- Workflow akan membangun APK debug otomatis ketika kamu mengunggah proyek ke branch main.
- Tidak perlu root.
- APK debug hanya untuk instalasi/pengujian pribadi, bukan rilis Play Store.

FITUR:
- Dashboard merah-hitam.
- Tombol membuka Free Fire MAX jika paket com.dts.freefiremax terpasang.
- Persentase baterai, suhu baterai, status termal Android, dan jenis jaringan.
- Pintasan Pengaturan Android.
- Tidak menampilkan angka FPS palsu.
- Tidak mengubah CPU/GPU atau mengaktifkan fitur internal REDMAGIC.

CARA BUILD VIA HP:
1. Buat akun GitHub dan verifikasi email.
2. Di Chrome, buka github.com lalu aktifkan "Desktop site" jika diperlukan.
3. Buat repository baru bernama RedMagic-iQOO-Dashboard. Pilih Private atau Public.
4. Ekstrak ZIP ini di HP menggunakan pengelola file.
5. Masuk ke repository > Add file > Upload files.
6. Unggah isi folder proyek (termasuk folder .github; pastikan file workflow ada di .github/workflows/build-apk.yml), bukan ZIP-nya saja.
7. Commit changes ke branch main.
8. Buka tab Actions > pilih "Build REDMAGIC iQOO Dashboard APK" > tunggu workflow selesai dengan tanda centang hijau.
9. Buka run yang berhasil, gulir ke Artifacts, lalu unduh REDMAGIC-iQOO-Dashboard-APK.
10. Ekstrak hasil artifact ZIP dan instal app-debug.apk di iQOO Z9.

CATATAN:
- GitHub Actions tersedia dengan batas pemakaian sesuai paket/kuota GitHub.
- Jika file .github tersembunyi tidak terlihat di pengelola file, aktifkan "Tampilkan file tersembunyi".
- Proyek memakai Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9, JDK 17, compileSdk 35.
- Dashboard tidak bisa membaca FPS game lain secara universal karena batasan Android.
